# app.py
from flask import Flask, request, render_template, send_file, redirect, url_for, flash
import os
from encryption_utils import encrypt_file, decrypt_file

app = Flask(__name__)
app.secret_key = "your-secret-flask-key"
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/")
def index():
    files = os.listdir(UPLOAD_FOLDER)
    return render_template("index.html", files=files)

@app.route("/upload", methods=["POST"])
def upload():
    if "file" not in request.files:
        flash("No file part")
        return redirect(url_for("index"))
    file = request.files["file"]
    if file.filename == "":
        flash("No selected file")
        return redirect(url_for("index"))
    data = file.read()
    encrypted_data = encrypt_file(data)
    with open(os.path.join(UPLOAD_FOLDER, file.filename + ".enc"), "wb") as f:
        f.write(encrypted_data)
    flash("✅ File uploaded and encrypted successfully!")
    return redirect(url_for("index"))

@app.route("/download/<filename>")
def download(filename):
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    if not os.path.exists(filepath):
        flash("❌ File not found")
        return redirect(url_for("index"))
    with open(filepath, "rb") as f:
        encrypted_data = f.read()
    decrypted_data = decrypt_file(encrypted_data)
    output_path = os.path.join(UPLOAD_FOLDER, "decrypted_" + filename.replace(".enc",""))
    with open(output_path, "wb") as f:
        f.write(decrypted_data)
    return send_file(output_path, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)
