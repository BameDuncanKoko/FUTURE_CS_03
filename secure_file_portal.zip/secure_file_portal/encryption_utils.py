from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import os

KEY_FILE = "keys/secret.key"

def load_key():
    if not os.path.exists("keys"):
        os.makedirs("keys")
    if not os.path.exists(KEY_FILE):
        key = get_random_bytes(32)
        with open(KEY_FILE, "wb") as f:
            f.write(key)
    else:
        with open(KEY_FILE, "rb") as f:
            key = f.read()
    return key

key = load_key()

def encrypt_file(input_data: bytes):
    iv = get_random_bytes(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    pad_len = 16 - (len(input_data) % 16)
    padded_data = input_data + bytes([pad_len]) * pad_len
    encrypted_data = cipher.encrypt(padded_data)
    return iv + encrypted_data

def decrypt_file(encrypted_data: bytes):
    iv = encrypted_data[:16]
    data = encrypted_data[16:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted_padded = cipher.decrypt(data)
    pad_len = decrypted_padded[-1]
    return decrypted_padded[:-pad_len]
